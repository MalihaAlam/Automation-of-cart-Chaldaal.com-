package PageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class pageobj {
    protected WebDriver driver;
    public pageobj (WebDriver driver){
        this.driver= driver;
        PageFactory.initElements(driver, this);
    }
}
