package PageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class formObjects extends pageobj{




//egg searching
    @FindBy (xpath ="//body/div[@id='page']/div[1]/div[3]/div[1]/div[1]/div[1]/form[1]/div[1]/input[1]")
    public WebElement  search;

    //add product button
    @FindBy (xpath ="//body/div[@id='page']/div[1]/div[5]/section[1]/div[1]/div[1]/div[1]/div[1]/section[1]/div[2]/div[2]/div[1]/section[1]")
    public WebElement addProduct;
//cart closing
    @FindBy (xpath ="//button[contains(text(),'Close')]")
    public WebElement closeCart;

    //food category selection from left list
    @FindBy (xpath ="//body/div[@id='page']/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[2]/ul[2]/li[6]/div[1]/a[1]")
    public WebElement food;

    //adding another egg to cart
   @FindBy (xpath ="//button[contains(text(),'+')]")
   public WebElement addAnotherEgg;

//cart opening
    @FindBy (xpath ="//body/div[@id='page']/div[1]/div[2]/div[1]/div[1]/section[1]/div[2]")
    public WebElement openCart;
    //minimizing egg quantity
    @FindBy (xpath ="//body/div[@id='page']/div[1]/div[2]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[2]/*[1]")
    public WebElement minimizingEggQuantity;


//place order button clicking
    @FindBy (xpath ="//button[@id='placeOrderButton']")
    public WebElement placeOrder;

    public formObjects (WebDriver driver){
        super(driver);
    }

}

