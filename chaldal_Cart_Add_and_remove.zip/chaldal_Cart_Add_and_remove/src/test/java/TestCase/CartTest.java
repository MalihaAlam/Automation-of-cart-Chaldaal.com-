package TestCase;

import Configuration.DriverSetup;
import PageObject.formObjects;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

public class CartTest extends DriverSetup  {

    public static String url= "https://chaldal.com" ;

    @Test
    public static void testFrom() throws InterruptedException {
        driver.get (url);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        Thread.sleep(5000);

        formObjects addDrop = new formObjects(driver) ;

        //egg searching
        addDrop.search.sendKeys("eggs") ;
        Thread.sleep(5000);

        //ager page e niye jabe (opening page)
        driver.navigate().back();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(5000);

        //abar eggs er page e niye jabe
        driver.navigate().forward() ;
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(5000);

    //add product button
        addDrop.addProduct.click();
        Thread.sleep(5000);
//cart closing
        addDrop.closeCart .click();
        Thread.sleep(4000);
//food category selection
        addDrop.food.click();
        Thread.sleep(4000);

//page scrolling
        JavascriptExecutor js = (JavascriptExecutor) driver;
//Find element by link text and store in variable "Element"
        WebElement Element = driver.findElement(By.xpath("//body/div[@id='page']/div[1]/div[5]/section[1]/div[1]/div[1]/div[1]/div[1]/section[1]/div[2]/div[1]/a[11]") );

        Thread.sleep(4000);
//This will scroll the page till the element is found
        js.executeScript("arguments[0].scrollIntoView();", Element);
        Thread.sleep(4000);
//scrolling up
        js.executeScript("window.scrollBy(0,-350);",Element);
        Thread.sleep(5000);



//ager page e niye jabe (eeg search)
        driver.navigate().back();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(4000);

        //adding another egg to cart
        addDrop.addAnotherEgg.click();
        Thread.sleep(4000);

//cart opening
        addDrop.openCart .click();
        Thread.sleep(5000);

        //minimizing egg quantity

        addDrop.minimizingEggQuantity .click();
        Thread.sleep(4000);

        //place order button clicking
        addDrop.placeOrder  .click();
        Thread.sleep(4000);

        //ager page e niye jabe (cart er page)
        driver.navigate().back();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(5000);


        //onno kono site er page e niye jabe
        driver.navigate().to("https://www.shwapno.com/");
       driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(5000);

    }
}
